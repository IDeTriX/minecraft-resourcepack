================================================================================
  ARMORED ELYTRA RESOURCE PACK
  Version 1.0
  Für Minecraft 1.20.5+
================================================================================

BESCHREIBUNG:
-------------
Dieses Resource Pack ändert die Textur der gepanzerten Elytren so, dass sie
wie die entsprechenden Brustpanzer aussehen.

- Leather Elytra -> Leather Chestplate Textur
- Gold Elytra -> Golden Chestplate Textur
- Chainmail Elytra -> Chainmail Chestplate Textur
- Iron Elytra -> Iron Chestplate Textur
- Diamond Elytra -> Diamond Chestplate Textur
- Netherite Elytra -> Netherite Chestplate Textur
- Copper Elytra -> Iron Chestplate Textur (als Platzhalter)


INSTALLATION:
-------------
Methode 1: Lokaler Client
1. Zippe den Ordner "ArmoredElytra_ResourcePack" zu einer .zip Datei
2. Öffne Minecraft
3. Gehe zu Options -> Resource Packs
4. Klicke auf "Open Pack Folder"
5. Kopiere die .zip Datei in diesen Ordner
6. Wähle das Pack in Minecraft aus

Methode 2: Server (Automatic Download)
1. Zippe den Ordner zu einer .zip Datei
2. Lade die Datei auf einen Webserver hoch
3. Füge folgendes zu deiner server.properties hinzu:
   resource-pack=<URL zur .zip Datei>
   resource-pack-sha1=<SHA1 Hash der Datei>
4. Server neu starten

Methode 3: Server (Manual)
1. Verteile die .zip Datei an alle Spieler
2. Spieler installieren es wie in Methode 1


SHA1 HASH ERSTELLEN:
--------------------
Windows PowerShell:
Get-FileHash ArmoredElytra_ResourcePack.zip -Algorithm SHA1

Linux/Mac:
shasum -a 1 ArmoredElytra_ResourcePack.zip


ANPASSUNGEN:
------------
Sie können die Texturen anpassen, indem Sie die Modell-Dateien bearbeiten:

assets/minecraft/models/item/armored_elytra/
├── leather.json
├── gold.json
├── chainmail.json
├── iron.json
├── diamond.json
├── netherite.json
└── copper.json

Ändern Sie einfach den "layer0" Wert auf eine andere Textur.

Beispiel für eine eigene Textur:
{
  "parent": "item/generated",
  "textures": {
    "layer0": "item/meine_eigene_textur"
  }
}

Dann fügen Sie Ihre Textur hinzu:
assets/minecraft/textures/item/meine_eigene_textur.png


HINWEISE:
---------
- Das Resource Pack funktioniert nur mit dem modifizierten ArmoredElytra Plugin
- Ohne das Plugin zeigen normale Elytren keine Änderungen
- Pack Format 22 ist für Minecraft 1.20.5 und höher
- Für ältere Versionen ändern Sie "pack_format" in pack.mcmeta


TROUBLESHOOTING:
----------------
Problem: Texturen werden nicht angezeigt
Lösung:
  - Überprüfen Sie, ob das Resource Pack aktiviert ist
  - Stellen Sie sicher, dass das Plugin die Custom Model Data setzt
  - Verwenden Sie /give @p minecraft:elytra{CustomModelData:5} zum Testen

Problem: "Incompatible" Warnung
Lösung:
  - Ändern Sie "pack_format" in pack.mcmeta entsprechend Ihrer Minecraft Version
  - Minecraft 1.20.5-1.20.6: pack_format 22
  - Minecraft 1.20.3-1.20.4: pack_format 18
  - Minecraft 1.20-1.20.2: pack_format 15


CREDITS:
--------
- ArmoredElytra Plugin von Pim16aap2
- Resource Pack erstellt für Custom Model Data Unterstützung
- Vanilla Minecraft Texturen von Mojang Studios


LIZENZ:
-------
Dieses Resource Pack verwendet die Standard Minecraft Texturen und ist
frei verwendbar für private Server und Spielwelten.
