================================================================================
  ARMORED ELYTRA - TEST RESOURCE PACK
  Version 1.0 TEST
================================================================================

ZWECK:
------
Dies ist ein VEREINFACHTES Test-Pack um zu überprüfen, ob das Custom Model
Data System funktioniert.

Es verwendet sehr einfache und deutlich erkennbare Texturen:

Leather Elytra    -> Leather (braun, deutlich)
Gold Elytra       -> Gold Ingot (golden, glänzend)
Chainmail Elytra  -> Chain (Kette)
Iron Elytra       -> Iron Ingot (grau)
Diamond Elytra    -> Diamond (türkis, sehr deutlich!)
Netherite Elytra  -> Netherite Ingot (dunkelgrau/schwarz)
Copper Elytra     -> Copper Ingot (orange/kupfer)


INSTALLATION:
-------------
1. Packen Sie diesen Ordner als .zip
   (Dateien müssen DIREKT in der .zip sein!)

2. Installieren Sie wie ein normales Resource Pack

3. Aktivieren Sie es in Minecraft


TESTEN:
-------
Methode 1: Mit Befehlen testen
```
/give @p minecraft:elytra{CustomModelData:5}
```
Sollte einen DIAMANTEN zeigen (türkis, sehr deutlich!)

Methode 2: Im Spiel craften
- Craften Sie eine gepanzerte Elytra im Amboss
- Diamond + Elytra = Item sollte wie ein Diamant aussehen


WARUM DIESES PACK?
------------------
Falls das Hauptpack nicht funktioniert, kann es mehrere Gründe haben:
1. Resource Pack wird nicht geladen
2. Custom Model Data wird nicht gesetzt
3. Texturen der Chestplates funktionieren nicht richtig

Dieses TEST-Pack verwendet die einfachsten möglichen Texturen (Items statt
Rüstungen), die GARANTIERT existieren und funktionieren sollten.


WENN ES FUNKTIONIERT:
---------------------
✅ Das System funktioniert grundsätzlich
✅ Custom Model Data wird gesetzt
✅ Resource Pack wird geladen

→ Das Problem liegt bei den Chestplate-Texturen im Hauptpack


WENN ES NICHT FUNKTIONIERT:
----------------------------
❌ Überprüfen Sie:
   1. Ist das Plugin installiert? (/plugins)
   2. Ist das Resource Pack aktiv? (Options → Resource Packs)
   3. Haben Sie F3+T gedrückt zum neu laden?
   4. Ist die .zip richtig gepackt? (pack.mcmeta direkt sichtbar?)


ERWARTETES ERGEBNIS:
--------------------
Diamond Armored Elytra = Zeigt einen türkisen DIAMANTEN (sehr auffällig!)
Iron Armored Elytra = Zeigt einen grauen EISENBARREN
Gold Armored Elytra = Zeigt einen goldenen GOLDBARREN
Etc.

Wenn Sie diese deutlichen Änderungen sehen → System funktioniert!